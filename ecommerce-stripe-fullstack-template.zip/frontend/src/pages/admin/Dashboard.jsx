
export default function Admin(){

return(
<div>
<h1>Admin Dashboard</h1>

<ul>
<li>Gerenciar produtos</li>
<li>Gerenciar pedidos</li>
<li>Ver vendas</li>
</ul>

</div>
)

}
