
import { useState } from 'react'
import axios from 'axios'

function App(){

const checkout = async()=>{

const res = await axios.post("http://localhost:5000/create-checkout-session",{
items:[{
price_data:{
currency:"usd",
product_data:{name:"Produto Demo"},
unit_amount:500
},
quantity:1
}]
})

window.location = `https://checkout.stripe.com/pay/${res.data.id}`

}

return(
<div style={{padding:40}}>

<h1>E-commerce Demo</h1>

<button onClick={checkout}>
Comprar com Stripe
</button>

</div>
)

}

export default App
