
require("dotenv").config()
const express = require("express")
const cors = require("cors")
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY)

const app = express()
app.use(cors())
app.use(express.json())

app.post("/create-checkout-session", async (req,res)=>{

const session = await stripe.checkout.sessions.create({
payment_method_types:["card"],
line_items:req.body.items,
mode:"payment",
success_url:"http://localhost:5173/success",
cancel_url:"http://localhost:5173/cancel"
})

res.json({id:session.id})

})

app.get("/",(req,res)=>{
res.send("API running")
})

app.listen(process.env.PORT || 5000,()=>{
console.log("server running")
})
